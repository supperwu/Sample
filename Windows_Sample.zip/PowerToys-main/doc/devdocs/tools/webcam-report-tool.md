# [WebcamReportTool](/tools/WebcamReportTool/)

This command line application generates a report about the connected webcams on the desktop called "WebcamReport.txt". The report contains the following information about every webcam:

* Name
* Supported formats
