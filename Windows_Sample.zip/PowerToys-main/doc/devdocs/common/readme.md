# Common

The [common](/src/common) folder contains projects with code, that is used in multiple projects.

## [FilePreviewCommon](FilePreviewCommon.md)

This project contains common code for file previewing.