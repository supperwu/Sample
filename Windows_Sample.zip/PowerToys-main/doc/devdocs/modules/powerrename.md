#### [`dllmain.cpp`](/src/modules/powerrename/dll/dllmain.cpp)
TODO

#### [`PowerRenameExt.cpp`](/src/modules/powerrename/dll/PowerRenameExt.cpp)
TODO

#### [`Helpers.cpp`](/src/modules/powerrename/lib/Helpers.cpp)
TODO

#### [`PowerRenameItem.cpp`](/src/modules/powerrename/lib/PowerRenameItem.cpp)
TODO

#### [`PowerRenameManager.cpp`](/src/modules/powerrename/lib/PowerRenameManager.cpp)
TODO

#### [`PowerRenameRegEx.cpp`](/src/modules/powerrename/lib/PowerRenameRegEx.cpp)
TODO

#### [`Settings.cpp`](/src/modules/powerrename/lib/Settings.cpp)
TODO

#### [`trace.cpp`](/src/modules/powerrename/lib/trace.cpp)
TODO
