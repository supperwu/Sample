//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PowerOCR.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys AdvancedPaste"
#define INTERNAL_NAME "PowerToys.AdvancedPasteModuleInterface"
#define ORIGINAL_FILENAME "PowerToys.AdvancedPasteModuleInterface.dll"

// Non-localizable
//////////////////////////////
