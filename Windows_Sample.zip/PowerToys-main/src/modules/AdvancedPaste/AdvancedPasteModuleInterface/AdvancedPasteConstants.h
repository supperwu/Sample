#pragma once
#include <string>

namespace AdvancedPasteConstants
{
    // Name of the powertoy module.
    inline const std::wstring ModuleKey = L"AdvancedPaste";
}