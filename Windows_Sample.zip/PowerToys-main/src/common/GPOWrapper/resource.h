//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PowerToys.MeasureToolCore.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys GPOWrapper"
#define INTERNAL_NAME "PowerToys.GPOWrapper"
#define ORIGINAL_FILENAME "PowerToys.GPOWrapper.dll"

// Non-localizable
//////////////////////////////
