#pragma once

#include "TraceLoggingProvider.h"
#include "TraceLoggingDefines.h"

TRACELOGGING_DECLARE_PROVIDER(g_hProvider);
