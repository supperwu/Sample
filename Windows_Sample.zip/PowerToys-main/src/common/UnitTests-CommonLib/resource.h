//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UnitTests-CommonLib.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys UnitTests-CommonLib"
#define INTERNAL_NAME "UnitTests-CommonLib"
#define ORIGINAL_FILENAME "UnitTests-CommonLib.dll"

// Non-localizable
//////////////////////////////
