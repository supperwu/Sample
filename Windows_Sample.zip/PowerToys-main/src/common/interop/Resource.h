//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by interop.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys Interop"
#define INTERNAL_NAME "PowerToys.Interop"
#define ORIGINAL_FILENAME "PowerToys.Interop.dll"

// Non-localizable
//////////////////////////////
