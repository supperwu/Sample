export const customTokenColors = [
    {token: 'custom-gitignore.negation', foreground: 'c00ce0'}
];