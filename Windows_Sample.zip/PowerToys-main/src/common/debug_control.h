#pragma once

// Prevent system-wide input lagging while paused in the debugger
//#define DISABLE_LOWLEVEL_HOOKS_WHEN_DEBUGGED
