#pragma once

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#include <winrt/base.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <Windows.h>