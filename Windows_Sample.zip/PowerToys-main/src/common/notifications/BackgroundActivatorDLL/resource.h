//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by notifications_dll.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys Notifications"
#define INTERNAL_NAME "Notifications"
#define ORIGINAL_FILENAME "PowerToys.BackgroundActivatorDLL.dll"

// Non-localizable
//////////////////////////////
