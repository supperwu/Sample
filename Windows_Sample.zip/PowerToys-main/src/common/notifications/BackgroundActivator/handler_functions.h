#pragma once

#include <string_view>

void dispatch_to_background_handler(std::wstring_view argument);
