//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PowerToys.Update.rc

//////////////////////////////
// Non-localizable

#define FILE_DESCRIPTION "PowerToys Update"
#define INTERNAL_NAME "PowerToys.Update"
#define ORIGINAL_FILENAME "PowerToys.Update.exe"

